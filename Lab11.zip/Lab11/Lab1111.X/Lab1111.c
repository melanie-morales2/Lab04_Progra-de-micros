/* 
 * File:   Lab1111.c
 * Author: melan
 *
 * Created on 14 de mayo de 2022, 11:19 PM
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

