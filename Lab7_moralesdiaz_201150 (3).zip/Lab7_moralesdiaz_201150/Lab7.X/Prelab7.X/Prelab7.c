/* 
 * File:   Prelab7.c  parte 1
 * Author: Melanie Morales
 *

 */

// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

#include <xc.h>
#include <stdint.h>  // Para poder usar los int de 8 bits
#include <stdio.h>

uint8_t X;

void setup(void);


void __interrupt() isr(void){
    if(INTCONbits.RBIF){        // Interrupcion puerto-B
        if(!PORTBbits.RB0)          // RB0-interrupci�n
        { X ++ ;                // Incremento puerto-A
            PORTA = X; 
            if (X==20)          //Reinicio de contador para usar valores entre 0-20
                X=0;
        }         
        else if(!PORTBbits.RB1)          //RB1-interrupci�n
        { X --;                 // Decremento puerto-A
            PORTA = X;          
              if(X==255)        //Reinicio de contador para usar valores entre 0-20
                  X=21;           
        }            
        INTCONbits.RBIF = 0;    //Limpiar flag de interrupci�n
    }
    return;
}
void main(void){
    setup();
    while(1){   
}
}
void setup(void){
    ANSEL = 0;
    ANSELH = 0;
    
    TRISA = ~0x1F;           // PuertoA-salida
    PORTA = 0;               // limpiar Puerto-A
    TRISC = ~0x1F;
    PORTC = 0; 
    
    TRISBbits.TRISB0 = 1;   // Puerto-B0 entrada
    TRISBbits.TRISB1 = 1;   // Puerto-B1 entrada
    OPTION_REGbits.nRBPU = 0;   //Pull up-B On
    WPUBbits.WPUB0 = 1;     // Pull up-B On RB0
    WPUBbits.WPUB1 = 1;     // Pull up-B On RB1
    INTCONbits.GIE = 1;     // Interrupciones globales
    INTCONbits.RBIE = 1;    // Interrupci�n Puerto-B
    IOCBbits.IOCB0 = 1;   // Interrupci�n cambio estado RB0
    IOCBbits.IOCB1 = 1;   // Interrupci�n cambio estado RB1
    INTCONbits.RBIF = 0;    // Limpiar flags interrupci�n
}
